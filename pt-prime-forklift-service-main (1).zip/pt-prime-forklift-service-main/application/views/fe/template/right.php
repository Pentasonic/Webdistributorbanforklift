<!-- STICKY TOOLS CONTACT-->
<div id="stickyTools">
    <div class="capsuleRed">
        <br>
        <a href="<?php echo base_url() ?>site/katalog" data-toggle="tooltip" data-placement="left" title="cart">
            <span><img src="<?php echo base_url() ?>assets/frontend/images/icon/cart.png" alt="logo">
                <br>
                <p class="hm-clr">Buy Parts</p>
            </span></a>

        <a href="<?php echo base_url() ?>site/hubungi" data-toggle="tooltip" data-placement="left" title="form">
            <span><img src="<?php echo base_url() ?>assets/frontend/images/icon/form.png" alt="logo">
                <br>
                <p class="hm-clr">Ask Quotes</p>
            </span></a>

        <!-- <a href="javascript:void(Tawk_API.toggle())" data-toggle="tooltip" data-placement="left" title="Chat">
            <span><img src="<?php echo base_url() ?>assets/frontend/images/icon/chat.png" alt="logo">
                <br>
                <p class="hm-clr">Live Chat</p>
            </span></a> -->

        <!--<a href="javascript:void();" data-placement="left" title="Chat"  data-toggle="modal" data-target="#exampleModal">
                <span><img src="<?php echo base_url() ?>assets/frontend/images/icon/chat.png" alt="logo">
                    <br>
                    <p class="hm-clr">Live Chat</p>
                </span></a>-->



        <a href="tel:+6282210812989" data-toggle="tooltip" data-placement="left" title="Call">
            <span><img src="<?php echo base_url() ?>assets/frontend/images/icon/call.png" alt="logo">
                <br>
                <p class="hm-clr">Call Center</p>
            </span></a>

        <a href="https://wa.me/6282210812989?text=Halo%20PT%20Prime%20Forklift%20Service" target="blank_" data-toggle="tooltip" data-placement="left" title="Whatssapp">
            <span><img src="<?php echo base_url() ?>assets/frontend/images/icon/whatsapp.png" alt="logo">
                <br>
                <p class="hm-clr">Whatsapp</p>
            </span></a>
    </div>
</div>