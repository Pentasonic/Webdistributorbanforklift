<div class="header-left">
    <ul class="mb-0 list-unstyled d-inline-flex">
        <li><a href="<?php echo base_url() ?>" title="">HOME</a></li>
        <li><a href="<?php echo base_url() ?>site/forklift" title="">BAN FORKLIFT</a></li>
        <li><a href="<?php echo base_url() ?>site/loader" title="">BAN LOADER</a></li>
        <li><a href="<?php echo base_url() ?>site/truck" title="">BAN TRUCK</a></li>
        <li><a href="<?php echo base_url() ?>site/press" title="">MOBILE PRESS BAN</a></li>
        <li><a href="<?php echo base_url() ?>site/artikel" title="">ARTIKEL</a></li>
        <li><a href="<?php echo base_url() ?>site/hubungi" title="">HUBUNGI KAMI</a></li>
    </ul>
</div>