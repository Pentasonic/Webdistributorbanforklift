<div class="col-md-3 col-sm-12 col-lg-3 catalog-filter">
    <div class="filter-form">
        <h4>Kategori Produk</h4>
        <ul class="list-unstyled">
            <li class="menu-item-has-children"><a href="<?php echo base_url() ?>site/forklift" title="" <?= ($this->uri->segment(2)== "forklift")? "class='active'":"" ?>>Ban Forklift</a>
                <ul class="mb-0 list-unstyled">
                    <!-- <li>
                        <a href="https://reviberkahmakmur.co.id/forklift/forklift-toyota/toyota-all" title="">Forklift Toyota</a>
                    </li>
                    <li>
                        <a href="https://reviberkahmakmur.co.id/forklift/forklift-mitsubishi/mitsubishi-all" title="">Forklift Mitsubishi</a>
                    </li>
                    <li>
                        <a href="https://reviberkahmakmur.co.id/forklift/forklift-tcm/tcm-all" title="">Forklift TCM</a>
                    </li> -->
                </ul>
            </li>
            <li class="menu-item-has-children"><a href="<?php echo base_url() ?>site/loader" title="" <?= ($this->uri->segment(2)== "loader")? "class='active'":"" ?>>Ban Loader</a>
                <ul class="mb-0 list-unstyled">
                    <!-- <li>
                        <a href="https://reviberkahmakmur.co.id/spare-parts/spare-parts-forklift/spare-parts-all" title="">Spare Parts Forklift</a>
                    </li>
                    <li>
                        <a href="https://reviberkahmakmur.co.id/spare-parts/attachment-forklift/attachment-all" title="">Attachment Forklift</a>
                    </li>
                    <li>
                        <a href="https://reviberkahmakmur.co.id/spare-parts/battery-forklift/battery-all" title="">Battery Forklift</a>
                    </li>
                    <li>
                        <a href="https://reviberkahmakmur.co.id/spare-parts/ban-forklift/ban-all" title="">Ban Forklift</a>
                    </li> -->
                </ul>
            </li>
            <li class="menu-item-has-children"><a href="<?php echo base_url() ?>site/truck" title="" <?= ($this->uri->segment(2)== "truck")? "class='active'":"" ?>>Ban Truck</a></li>
            <li class="menu-item-has-children"><a href="<?php echo base_url() ?>site/press" title="" <?= ($this->uri->segment(2)== "press")? "class='active'":"" ?>>Mobile Press Ban</a></li>
        </ul>
    </div>
</div>