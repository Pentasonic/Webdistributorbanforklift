(function(global){var Language = {};

Language.pluralFormFunction = function (n) {
		return 'other';
	};


Language.bubble = Language.bubble || {};

Language.bubble.attention_grabber = {
	"message": "Penarik perhatian obrolan"
};


Language.chat = Language.chat || {};

Language.chat.Warning = {
	"message": "Peringatan"
};
Language.chat.accept_call = {
	"message": "Terima"
};
Language.chat.active = {
	"message": "Aktif"
};
Language.chat.agent_profile_image = {
	"message": "Gambar Profil Agen"
};
Language.chat.agent_ringing = {
	"message": "Panggilan masuk"
};
Language.chat.all_conversations = {
	"message": "Lihat semua percakapan"
};
Language.chat.call_end_details = {
	"message": "Dimulai di #startedOn dan berlangsung #duration",
	"vars": [
		"startedOn",
		"duration"
	]
};
Language.chat.call_error_load = {
	"message": "Tidak dapat memuat detail panggilan."
};
Language.chat.call_started_on = {
	"message": "Dimulai di #startedOn",
	"vars": [
		"startedOn"
	]
};
Language.chat.chatEnded = {
	"message": "Obrolan Anda telah berakhir"
};
Language.chat.chat_icon = {
	"message": "Ikon obrolan"
};
Language.chat.chat_qm = {
	"message": "Mulai mengobrol?"
};
Language.chat.chat_text = {
	"message": "Obrolan"
};
Language.chat.close_icon = {
	"message": "Tutup ikon"
};
Language.chat.completed_call = {
	"message": "Panggilan berakhir"
};
Language.chat.conversation_ended_on = {
	"message": "Conversation ended on"
};
Language.chat.decline_call = {
	"message": "Tolak"
};
Language.chat.defaultName = {
	"message": "Anda (ubah nama)"
};
Language.chat.departmentIsAway = {
	"message": "Department #strongStart #departmentName #strongEnd sedang tidak ada di tempat.",
	"vars": [
		"departmentName",
		"strongStart",
		"strongEnd"
	]
};
Language.chat.departmentIsOffline = {
	"message": "Departemen #strongStart #departmentName #strongEnd sedang offline. Anda akan dilayani oleh departemen lain.",
	"vars": [
		"departmentName",
		"strongStart",
		"strongEnd"
	]
};
Language.chat.download = {
	"message": "Unduhan"
};
Language.chat.downloadFile = {
	"message": "Unduh File"
};
Language.chat.dragDropText = {
	"message": "Tarik file ke sini untuk meng-unggah"
};
Language.chat.emoji_error_load = {
	"message": "Tidak dapat memuat ikon emosi"
};
Language.chat.error_title = {
	"message": "Kesalahan"
};
Language.chat.failed = {
	"message": "Gagal"
};
Language.chat.generalUploadError = {
	"message": "\"#fileName\", silakan coba lagi.",
	"vars": [
		"fileName"
	]
};
Language.chat.generalUploadErrorLabel = {
	"message": "Tidak dapat mengunggah file"
};
Language.chat.goToLatest = {
	"message": "Buka terakhir"
};
Language.chat.hideButton = {
	"message": "Sembunyikan Obrolan"
};
Language.chat.incoming_call_message = {
	"message": "Panggilan masuk dari #name",
	"vars": [
		"name"
	]
};
Language.chat.insert_emoji = {
	"message": "Sisipkan emoji"
};
Language.chat.justNow = {
	"message": "baru-baru ini"
};
Language.chat.limit2 = {
	"message": "Ukuran maksimum file 2MB untuk seluler, silahkan upload file yang lebih kecil."
};
Language.chat.limit50 = {
	"message": "Ukuran file maksimum 50MB, silahkan upload file yang lebih kecil."
};
Language.chat.message_not_delivered = {
	"message": "Pesan tidak terkirim, klik disini untuk mengirim ulang."
};
Language.chat.message_too_long = {
	"message": "Pesan tidak dapat melebihi 5000 karakter"
};
Language.chat.missed_agent = {
	"message": "Teleponmu tidak terjawab"
};
Language.chat.missed_visitor = {
	"message": "Anda melewatkan sebuah panggilan"
};
Language.chat.missed_visitor_messagePreview = {
	"message": "Anda melewatkan panggilan dari"
};
Language.chat.mobileName = {
	"message": "Anda"
};
Language.chat.newChat = {
	"message": "Mulai Obrolan Baru"
};
Language.chat.newMessages = {
	"message": "Pesan Baru"
};
Language.chat.new_conversation = {
	"message": "Percakapan Baru"
};
Language.chat.notificationTitle = {
	"message": "pemberitahuan"
};
Language.chat.ongoing_call = {
	"message": "Panggilan yang sedang berlangsung"
};
Language.chat.past = {
	"message": "#time lalu",
	"vars": [
		"time"
	]
};
Language.chat.pasted_image_title = {
	"message": "Gambar disisipkan pada #dateTime",
	"vars": [
		"dateTime"
	]
};
Language.chat.profile_prechat_text = {
	"message": "Mohon isi formulir di bawah untuk mulai berbicara dengan saya."
};
Language.chat.rejected_call = {
	"message": "Anda menolak panggilan ini"
};
Language.chat.remove_rate = {
	"message": "Anda menghapus penilaian anda untuk percakapan ini"
};
Language.chat.resend = {
	"message": "Kirim ulang"
};
Language.chat.retry = {
	"message": "Coba lagi."
};
Language.chat.return_to_live_chat = {
	"message": "Return to live chat"
};
Language.chat.say_something = {
	"message": "Tulis balasan.."
};
Language.chat.screen_share_error = {
	"message": "Berbagi layar tidak tersedia."
};
Language.chat.send_mail = {
	"message": "Kirimkan Surat"
};
Language.chat.sent_file = {
	"message": "Mengirim berkas"
};
Language.chat.today_time = {
	"message": "Hari ini, #time",
	"vars": [
		"time"
	]
};
Language.chat.tryAgain = {
	"message": "Coba lagi."
};
Language.chat.unanswered = {
	"message": "Tidak terjawab"
};
Language.chat.uploading = {
	"message": "Mengunggah..."
};
Language.chat.video_call_error = {
	"message": "Panggilan video tidak tersedia."
};
Language.chat.visitor_ringing = {
	"message": "Panggilan..."
};
Language.chat.voice_call_error = {
	"message": "Panggilan suara tidak tersedia."
};
Language.chat.we_are_live = {
	"message": "Kami sedang online dan siap berinteraksi dengan Anda sekarang.\nKatakan sesuatu untuk memulai obrolan langsung."
};


Language.days = Language.days || {};

Language.days['0'] = {
	"message": "Minggu"
};
Language.days['1'] = {
	"message": "Senin"
};
Language.days['2'] = {
	"message": "Selasa"
};
Language.days['3'] = {
	"message": "Rabu"
};
Language.days['4'] = {
	"message": "Kamis"
};
Language.days['5'] = {
	"message": "Jumat"
};
Language.days['6'] = {
	"message": "Sabtu"
};


Language.form = Language.form || {};

Language.form.CancelButton = {
	"message": "Batal"
};
Language.form.CloseButton = {
	"message": "Tutup"
};
Language.form.DepartmentsErrorMessage = {
	"message": "Departemen harus diisi."
};
Language.form.DepartmentsPlaceholder = {
	"message": "pilih departemen.."
};
Language.form.EmailErrorMessage = {
	"message": "Alamat surel tidak valid."
};
Language.form.EmailPlaceholder = {
	"message": "Alamat Email"
};
Language.form.EmailTranscriptFormMessage = {
	"message": "Mohon isi formulir di bawah untuk mengirimkan obrolan ini ke alamat surel Anda."
};
Language.form.EmailTranscriptSuccess = {
	"message": "Permintaan transkrip surel terkirim."
};
Language.form.EmailTranscriptTo = {
	"message": "Transkrip ke email"
};
Language.form.EndChatMessage = {
	"message": "Terimakasih. Jangan sungkan untuk memulai obrolan baru atau tulis email anda dan kirimkan transkrip percakapan ini ke email."
};
Language.form.EndChatMessage2 = {
	"message": "Terima kasih telah menghubungi kami. Jangan ragu untuk kembali menghubungi kami."
};
Language.form.EndChatTitle = {
	"message": "Apakah Anda yakin ingin mengakhiri obrolan ini?"
};
Language.form.MessagePlaceholder = {
	"message": "pesan Anda.."
};
Language.form.NameErrorMessage = {
	"message": "Nama harus diisi."
};
Language.form.NameFormMessage = {
	"message": "Mohon ganti nama Anda sehingga kami dapat mengenali Anda lain kali."
};
Language.form.OfflineFormMessage = {
	"message": "Mohon isi formulir di bawah dan kami akan membalasnya sesegera mungkin."
};
Language.form.OfflineMessageNotSent = {
	"message": "Pesan tidak terkirim, silahkan coba lagi"
};
Language.form.OfflineMessageSent = {
	"message": "Pesan berhasil dikirim!"
};
Language.form.PhoneErrorMessage = {
	"message": "Nomor ponsel tidak valid"
};
Language.form.PreChatFormMessage = {
	"message": "Mohon isi formulir di bawah untuk mulai ngobrol dengan agen selanjutnya yang ada."
};
Language.form.PreChatFormMessageProfile = {
	"message": "Mohon isi formulir di bawah untuk mulai ngobrol dengan saya."
};
Language.form.QuestionPlaceholder = {
	"message": "pertanyaan Anda.."
};
Language.form.RequiredErrorMessage = {
	"message": "Bagian ini diperlukan"
};
Language.form.SaveButton = {
	"message": "Simpan"
};
Language.form.SendButton = {
	"message": "Kirim"
};
Language.form.SendMessage = {
	"message": "Kirim pesan"
};
Language.form.StartChatButton = {
	"message": "Mulai Obrolan"
};
Language.form.SubmitButton = {
	"message": "Kirim"
};
Language.form.SubmittedFrom = {
	"message": "Dikirim dari"
};
Language.form.SubmittingProcess = {
	"message": "Mengirimkan"
};
Language.form.TranscriptMessage = {
	"message": "Jangan sungkan untuk menuliskan email anda dan kirimkan transkrip percakapan ini ke email."
};
Language.form.any = {
	"message": "Setiap"
};
Language.form.chatEnded = {
	"message": "Obrolan anda berakhir"
};
Language.form.department = {
	"message": "Departemen"
};
Language.form.email = {
	"message": "Email"
};
Language.form.errorSaving = {
	"message": "Tidak dapat menyimpan. Mohon coba lagi"
};
Language.form.message = {
	"message": "Pesan"
};
Language.form.name = {
	"message": "Nama"
};
Language.form.sendAgain = {
	"message": "Kirim lagi"
};
Language.form.visitButton = {
	"message": "Kunjungi tawk.to"
};


Language.home = Language.home || {};

Language.home.banner_image = {
	"message": "Gambar Banner"
};
Language.home.chat_button = {
	"message": "Percakapan Baru"
};
Language.home.chat_input = {
	"message": "Tulis di sini dan klik enter.."
};
Language.home.heading_main = {
	"message": "Hai 👋"
};
Language.home.heading_sub = {
	"message": "Perlu bantuan? Cari jawaban di pusat bantuan atau mulai percakapan."
};
Language.home.kb_search = {
	"message": "Cari Jawaban"
};
Language.home.logo_image = {
	"message": "Gambar Logo"
};


Language.kb = Language.kb || {};

Language.kb.article_image = {
	"message": "Gambar Artikel"
};
Language.kb.article_rating = {
	"message": "Apakah artikel ini bermanfaat?"
};
Language.kb.article_rating_count = {
	"message": "#totalLikes dari #totalVotes menyukai artikel ini",
	"vars": [
		"totalLikes",
		"totalVotes"
	]
};
Language.kb.author_profile_image = {
	"message": "Foto Profil Penulis"
};
Language.kb.clear_search = {
	"message": "Bersihakan Pencarian"
};
Language.kb.downvote_rating_button = {
	"message": "Tidak"
};
Language.kb.help_center = {
	"message": "Pusat Bantuan"
};
Language.kb.negative_rating = {
	"message": "Negatif"
};
Language.kb.positive_rating = {
	"message": "Positif"
};
Language.kb.recent_searches = {
	"message": "Pencarian sebelumnya"
};
Language.kb.search_fail_description = {
	"message": "Silahkan dicoba kembali"
};
Language.kb.search_fail_title = {
	"message": "Hasil pencarian tidak ditemukan."
};
Language.kb.search_placeholder = {
	"message": "Cari jawaban"
};
Language.kb.search_results = {
	"message": "Hasil Pencarian"
};
Language.kb.show_all_results = {
	"message": "Tampilkan semua hasil (#num)",
	"vars": [
		"num"
	]
};
Language.kb.submit_search = {
	"message": "Kirim Pertanyaan"
};
Language.kb.upvote_rating_button = {
	"message": "Ya"
};
Language.kb.view_full = {
	"message": "Tampilkan lebih lengkap"
};


Language.menu = Language.menu || {};

Language.menu.add_chat_to_your_website = {
	"message": "Add Chat to your website"
};
Language.menu.change_name = {
	"message": "Ubah Nama"
};
Language.menu.email_transcript = {
	"message": "Transkrip email"
};
Language.menu.end_chat_session = {
	"message": "Akhiri sesi obrolan ini"
};
Language.menu.popout_widget = {
	"message": "Kemunculan widget"
};
Language.menu.sound_off = {
	"message": "Suara Mati"
};
Language.menu.sound_on = {
	"message": "Suara Aktif"
};


Language.months = Language.months || {};

Language.months['0'] = {
	"message": "Januari"
};
Language.months['1'] = {
	"message": "Februari"
};
Language.months['10'] = {
	"message": "November"
};
Language.months['11'] = {
	"message": "Desember"
};
Language.months['2'] = {
	"message": "Maret"
};
Language.months['3'] = {
	"message": "April"
};
Language.months['4'] = {
	"message": "Mei"
};
Language.months['5'] = {
	"message": "Juni"
};
Language.months['6'] = {
	"message": "Juli"
};
Language.months['7'] = {
	"message": "Agustus"
};
Language.months['8'] = {
	"message": "September"
};
Language.months['9'] = {
	"message": "Oktober"
};


Language.notifications = Language.notifications || {};

Language.notifications.dismiss_alert = {
	"message": "Sudahi Peringatan"
};
Language.notifications.maximum_file_upload_warning = {
	"message": "Maaf, batas transfer file adalah #limitFileNumber file. Silakan coba lagi file(-file) berikut ini :",
	"vars": [
		"limitFileNumber"
	]
};
Language.notifications.maximum_size_upload_warning = {
	"message": "Maaf, file transfer telah di batasi maksimal #limitFileSize setiap file. Silahkan kompres file-file berikut dan mencoba kembali.",
	"vars": [
		"limitFileSize"
	]
};
Language.notifications.reconnecting = {
	"message": "Menyambungkan kembali"
};
Language.notifications.retry = {
	"message": "Coba lagi"
};


Language.overlay = Language.overlay || {};

Language.overlay.cookiesOff = {
	"message": "Anda tidak dapat menggunakan obrolan ini karena fungsi cookie peramban Anda dimatikan. Mohon nyalakan dan refresh peramban Anda."
};
Language.overlay.inactive = {
	"message": "Klik di sini untuk memulai ulang percakapan"
};
Language.overlay.maintenance = {
	"message": "Obrolan sedang menjalani perbaikan"
};
Language.overlay.tawkContent = {
	"message": "Widget ini dijalankan oleh tawk.to - aplikasi pesan gratis yang memonitor dan mengikut sertakan pengunjung laman web anda."
};


Language.rollover = Language.rollover || {};

Language.rollover.back = {
	"message": "Kembali"
};
Language.rollover.chatMenu = {
	"message": "Menu"
};
Language.rollover.emailTranscriptOption = {
	"message": "Transkrip Email"
};
Language.rollover.end = {
	"message": "Akhiri Obrolan"
};
Language.rollover.knowledgeBase = {
	"message": "basis Pengetahuan"
};
Language.rollover.maximize = {
	"message": "Perbesar"
};
Language.rollover.minimize = {
	"message": "Perkecil"
};
Language.rollover.negativeRating = {
	"message": "Beri nilai obrolan ini dengan -1"
};
Language.rollover.popOut = {
	"message": "Munculkan"
};
Language.rollover.positiveRating = {
	"message": "Beri nilai obrolan ini dengan +1"
};
Language.rollover.rateChat = {
	"message": "Berikan penilaian untuk obrolan ini."
};
Language.rollover.resendMessage = {
	"message": "Kirim ulang pesan"
};
Language.rollover.resize = {
	"message": "Atur Ukuran"
};
Language.rollover.screenShare = {
	"message": "Berbagi layar"
};
Language.rollover.uploadFile = {
	"message": "Unggah File"
};
Language.rollover.videoCall = {
	"message": "Panggilan Video"
};
Language.rollover.voiceCall = {
	"message": "Panggilan suara"
};


Language.routes = Language.routes || {};

Language.routes.all_agents = {
	"message": "Semua Agen"
};
Language.routes.conversations = {
	"message": "Percakapan"
};
Language.routes.load_more = {
	"message": "Tampilkan Lebih Banyak"
};


Language.status = Language.status || {};

Language.status.away = {
	"message": "Pergi"
};
Language.status.offline = {
	"message": "Offline"
};
Language.status.online = {
	"message": "Online"
};




Language.chat = Language.chat || {};

Language.chat.hours = {
	"pluralVars": [
		"num"
	],
	"message": {
		"other": "#num Jam"
	}
};
Language.chat.messageQueuedText = {
	"pluralVars": [
		"t"
	],
	"message": {
		"other": "Perkiraan waktu tunggu ialah #strongStart #t menit #strongEnd"
	},
	"vars": [
		"strongStart",
		"strongEnd"
	]
};
Language.chat.minutes = {
	"pluralVars": [
		"num"
	],
	"message": {
		"other": "#num Menit"
	}
};
Language.chat.newMessage = {
	"pluralVars": [
		"num"
	],
	"message": {
		"other": "#num pesan baru"
	}
};
Language.chat.seconds = {
	"pluralVars": [
		"num"
	],
	"message": {
		"other": "#num Detik"
	}
};


global.$_Tawk.language = Language;})(window);